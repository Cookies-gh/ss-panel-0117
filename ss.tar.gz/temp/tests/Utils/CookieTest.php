<?php

namespace Tests\Utils;

use Tests\TestCase;

class CookieTest extends TestCase
{
    public function testCookie()
    {
        $key = "key";
        $value = "value";
        $ary = [
            $key => $value
        ];
       
    }
}