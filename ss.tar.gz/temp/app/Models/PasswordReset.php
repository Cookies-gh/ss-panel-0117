<?php

namespace App\Models;


class PasswordReset extends Model
{
    protected $table = 'ss_password_reset';
}