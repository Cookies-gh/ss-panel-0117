<?php

namespace App\Models;


class Token extends Model
{
    protected $table = "user_token";
}