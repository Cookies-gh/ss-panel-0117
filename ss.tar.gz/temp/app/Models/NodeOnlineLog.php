<?php


namespace App\Models;


class NodeOnlineLog extends Model
{
    protected $table = "ss_node_online_log";
}