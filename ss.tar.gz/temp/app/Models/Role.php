<?php

namespace App\Models;

/**
 * Node Model
 */

class Role extends Model

{
    protected $table = "user_role";

}
