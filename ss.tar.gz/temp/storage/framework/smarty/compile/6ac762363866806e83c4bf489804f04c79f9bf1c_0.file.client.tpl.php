<?php
/* Smarty version 3.1.29, created on 2016-10-12 15:00:01
  from "/home/wwwroot/default/ss-panel/resources/views/default/client.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_57fddf71b50861_66168644',
  'file_dependency' => 
  array (
    '6ac762363866806e83c4bf489804f04c79f9bf1c' => 
    array (
      0 => '/home/wwwroot/default/ss-panel/resources/views/default/client.tpl',
      1 => 1476255593,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_57fddf71b50861_66168644 ($_smarty_tpl) {
$_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<div class="section no-pad-bot" id="index-banner">
    <div class="container">
        <div>
            <h5><b>客户端下载</b></h5>
			<br><a href="http://159.203.62.90/windows.zip"><b>Windows</b></a><br>
			<br><a href="http://159.203.62.90/mac.zip"><b>Mac</b></a><br>
			<br><a href="http://159.203.62.90/android.zip"><b>Android</b></a><br>
			<br><a href="http://159.203.62.90/linux.zip"><b>Linux</b></a><br>
			<br><br>
			<br><br>
			<br><br>
        </div>
    </div>
</div>

<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<?php }
}
