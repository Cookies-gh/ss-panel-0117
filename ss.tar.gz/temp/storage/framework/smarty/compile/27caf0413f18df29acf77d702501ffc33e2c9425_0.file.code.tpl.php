<?php
/* Smarty version 3.1.29, created on 2016-06-28 12:56:43
  from "/home/wwwroot/default/ss-panel/resources/views/default/code.tpl" */

if ($_smarty_tpl->smarty->ext->_validateCompiled->decodeProperties($_smarty_tpl, array (
  'has_nocache_code' => false,
  'version' => '3.1.29',
  'unifunc' => 'content_5772038b0698f2_55657237',
  'file_dependency' => 
  array (
    '27caf0413f18df29acf77d702501ffc33e2c9425' => 
    array (
      0 => '/home/wwwroot/default/ss-panel/resources/views/default/code.tpl',
      1 => 1467081045,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:header.tpl' => 1,
    'file:footer.tpl' => 1,
  ),
),false)) {
function content_5772038b0698f2_55657237 ($_smarty_tpl) {
$_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>

<div class="section no-pad-bot" id="index-banner">
    <div class="container">
        <br><br>
		<br><br>
        <div class="row center">
            
            <h4>本站不开放注册，邀请码请联系系统管理员获取。</h4>
			<br><br>
			<br><br>
			<br><br>
			<br><br>
			<br><br>
			<br><br>
            <?php echo $_smarty_tpl->tpl_vars['msg']->value;?>

        </div>
    </div>
</div>

<?php $_smarty_tpl->smarty->ext->_subtemplate->render($_smarty_tpl, "file:footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}
}
